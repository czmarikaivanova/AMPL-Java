This folder contains  three sub-folders (Range_100, Range_125 and Range_150).
Each sub-folder contains 18 instances.
Folder "Range_100" contains instances with the range 100m.
Folder "Range_125" contains instances with the range 125m.
Folder "Range_150" contains instances with the range 150m.
---------------------------------------------------------
Instance representation.
First row indicates the number of nodes and number of edges.
From second row onwards is the adjacency list of (undirected) edges in the graph in the form x y w where x and y (x < y) are endpoints of undirected edge (x, y) with weight w
-----------------------------------------------------------------------
So an instance file will appear as follows:
-----------------------------------------------------------------------
Total_number_of_nodes   Total_number_of_edges
node  node  weight
       .
       .
       .
node  node  weight     
